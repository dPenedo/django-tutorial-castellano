---
name: Documentation Problem
about: Missing, incomplete or incorrect information in the documentation
title: ''
labels: docs
assignees: ''

---

**What page or section of the docs have an issue?**
Please include a link

**Describe the issue**
A clear and concise description of what you were looking for, couldn't find, or
the where things were misleading etc.

