# `domain:domain_id()`

{{since('20230320-124340-559cb7b0')}}

Returns the domain id.

