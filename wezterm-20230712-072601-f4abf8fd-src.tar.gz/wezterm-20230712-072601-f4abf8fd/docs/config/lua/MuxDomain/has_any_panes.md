# `domain:has_any_panes()`

{{since('20230320-124340-559cb7b0')}}

Returns `true` if the mux has any panes that belong to this domain.

This can be useful when deciding whether to spawn additional panes after
attaching to a domain.

