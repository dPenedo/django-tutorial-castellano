# `domain:is_spawnable()`

{{since('20230320-124340-559cb7b0')}}

Returns `false` if this domain will never be able to spawn a new pane/tab/window, `true` otherwise.

Serial ports are represented by a serial domain that is not spawnable.


