# `domain:label()`

{{since('20230320-124340-559cb7b0')}}

Computes a label describing the name and state of the domain.
The label can change depending on the state of the domain.

See also: [domain:name()](name.md).

