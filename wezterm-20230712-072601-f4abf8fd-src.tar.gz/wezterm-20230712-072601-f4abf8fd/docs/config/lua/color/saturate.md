# `color:saturate(factor)`

{{since('20220807-113146-c2fee766')}}

Scales the color towards the maximum saturation by the provided factor, which
should be in the range `0.0` through `1.0`.


