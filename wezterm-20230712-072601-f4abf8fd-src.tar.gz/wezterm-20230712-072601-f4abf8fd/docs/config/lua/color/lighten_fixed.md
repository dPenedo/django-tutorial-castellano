# `color:lighten_fixed(amount)`

{{since('20220807-113146-c2fee766')}}

Increase the lightness by amount, a value ranging from `0.0` to `1.0`.


