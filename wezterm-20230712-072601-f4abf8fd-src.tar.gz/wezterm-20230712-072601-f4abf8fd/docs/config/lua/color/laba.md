# `color:laba()`

{{since('20220807-113146-c2fee766')}}

Converts the color to the LAB colorspace and returns those values +
alpha:

```lua
local l, a, b, alpha = color:laba()
```


