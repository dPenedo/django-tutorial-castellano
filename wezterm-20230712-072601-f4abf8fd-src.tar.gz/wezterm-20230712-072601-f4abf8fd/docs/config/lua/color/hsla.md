# `color:hsla()`

{{since('20220807-113146-c2fee766')}}

Converts the color to the HSL colorspace and returns those values +
alpha:

```lua
local h, s, l, a = color:hsla()
```


