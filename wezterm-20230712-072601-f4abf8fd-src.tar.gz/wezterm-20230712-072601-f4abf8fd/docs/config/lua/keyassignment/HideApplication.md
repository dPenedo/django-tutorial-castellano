# `HideApplication`

On macOS, hide the WezTerm application.

```lua
config.keys = {
  { key = 'h', mods = 'CMD', action = wezterm.action.HideApplication },
}
```
