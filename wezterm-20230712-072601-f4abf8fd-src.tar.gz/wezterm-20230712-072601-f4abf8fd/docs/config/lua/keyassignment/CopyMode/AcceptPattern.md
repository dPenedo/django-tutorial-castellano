# CopyMode `AcceptPattern`

{{since('20220624-141144-bd1b7c5d')}}

Take CopyMode/SearchMode out of editing mode: keyboard input will no longer be
directed to the search pattern editor.

See also [EditPattern](EditPattern.md).

