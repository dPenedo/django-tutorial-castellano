# `Hide`

Hides (or minimizes, depending on the platform) the current window.

```lua
config.keys = {
  { key = 'h', mods = 'CMD', action = wezterm.action.Hide },
}
```
