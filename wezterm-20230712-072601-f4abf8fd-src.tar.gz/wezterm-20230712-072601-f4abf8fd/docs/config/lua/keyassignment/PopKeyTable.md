# `PopKeyTable`

{{since('20220408-101518-b908e2dd')}}

Pops the current key table, if any, from the activation stack.

See [Key Tables](../../key-tables.md) for a detailed example.
