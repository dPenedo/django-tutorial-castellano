# `ClearKeyTableStack`

{{since('20220408-101518-b908e2dd')}}

Clears the entire key table stack.

Note that this is triggered implicitly when the configuration is reloaded.
