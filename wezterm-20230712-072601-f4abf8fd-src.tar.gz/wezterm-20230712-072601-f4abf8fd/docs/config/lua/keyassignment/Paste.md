# `Paste`

Paste the clipboard to the current pane.

{{since('20210203-095643-70a364eb')}}

This action is considered to be deprecated and will be removed in
a future release; please use [PasteFrom](PasteFrom.md) instead.

{{since('20230320-124340-559cb7b0')}}

!!! warning
    This action has been removed. Please use [PasteFrom](PasteFrom.md) instead.

