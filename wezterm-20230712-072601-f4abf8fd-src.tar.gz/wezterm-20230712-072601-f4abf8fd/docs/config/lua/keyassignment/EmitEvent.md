# `EmitEvent`

{{since('20201031-154415-9614e117')}}

This action causes the equivalent of `wezterm.emit(name, window, pane)` to be
called in the context of the current pane.

See [the Custom Events example](../wezterm/on.md#custom-events) for a detailed
example of using this action.

