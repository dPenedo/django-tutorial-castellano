# `ReloadConfiguration`

Explicitly reload the configuration.

```lua
config.keys = {
  {
    key = 'r',
    mods = 'CMD|SHIFT',
    action = wezterm.action.ReloadConfiguration,
  },
}
```


