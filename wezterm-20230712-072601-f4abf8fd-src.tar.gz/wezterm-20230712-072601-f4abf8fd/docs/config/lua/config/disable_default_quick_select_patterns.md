---
tags:
  - quick_select
---
# `disable_default_quick_select_patterns = false`

{{since('20210502-130208-bff6815d')}}

When set to `true`, the default set of quick select patterns
are omitted, and your [quick_select_patterns](quick_select_patterns.md)
config specifies the total set of patterns used for [quick select mode](../../../quickselect.md).

Defaults to `false`.
