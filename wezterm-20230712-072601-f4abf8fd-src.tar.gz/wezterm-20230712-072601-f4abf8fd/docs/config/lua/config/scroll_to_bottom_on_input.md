---
tags:
  - keys
---
# `scroll_to_bottom_on_input`

When `true` (the default), the viewport will automatically scroll to the
bottom of the scrollback when there is input to the terminal so that you
can see what you are typing.
