---
tags:
  - tab_bar
---
# `use_fancy_tab_bar = true`

{{since('20220101-133340-7edc5b5a')}}

When set to `true` (the default), the tab bar is rendered in
a native style with proportional fonts.

When set to `false`, the tab bar is rendered using a retro
aesthetic using the main terminal font.

