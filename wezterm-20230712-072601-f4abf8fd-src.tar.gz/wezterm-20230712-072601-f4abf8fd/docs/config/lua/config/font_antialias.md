---
tags:
  - font
---
# `font_antialias = "Greyscale"`

*Deprecated starting in version 20210314-114017-04b7cedd; this option no longer does anything and will be removed in a future release. Use [freetype_load_target](freetype_load_target.md) instead*

Adjusts the anti-aliasing portion of the font rasterizer.

Possible values are `None`, `Greyscale`, `Subpixel`.

The default value is `Greyscale`.

