---
tags:
  - appearance
  - char_select
  - font
---
# `char_select_font_size = 14.0`

{{since('20220903-194523-3bb1ed61')}}

Specifies the size of the font used with
[CharSelect](../keyassignment/CharSelect.md).
