---
tags:
  - font
---
# `font_size = 10.0`

Specifies the size of the font, measured in points.

You may use fractional point sizes, such as `13.3`, to fine tune the size.

The default font size is `10.0` points.

{{since('20210314-114017-04b7cedd')}}

The default font size is now `12.0` points.

