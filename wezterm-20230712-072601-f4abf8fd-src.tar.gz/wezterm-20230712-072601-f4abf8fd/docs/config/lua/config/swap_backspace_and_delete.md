---
tags:
  - keys
---
# `swap_backspace_and_delete = false`

When set to `true`, switch the interpretation of the `Backspace` and
`Delete` keys such that `Backspace` generates `Delete` and vice versa.

