---
tags:
  - tab_bar
  - appearance
---
# `hide_tab_bar_if_only_one_tab = false`

If set to true, when there is only a single tab, the tab bar is
hidden from the display.  If a second tab is created, the tab
will be shown.

See also [enable_tab_bar](enable_tab_bar.md)
