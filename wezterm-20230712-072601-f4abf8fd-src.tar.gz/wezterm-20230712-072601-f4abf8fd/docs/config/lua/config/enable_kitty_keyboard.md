---
tags:
  - keys
---
# `enable_kitty_keyboard = false`

{{since('20220624-141144-bd1b7c5d')}}

When set to `true`, wezterm will honor kitty keyboard protocol escape
sequences that modify the [keyboard encoding](../../key-encoding.md).


