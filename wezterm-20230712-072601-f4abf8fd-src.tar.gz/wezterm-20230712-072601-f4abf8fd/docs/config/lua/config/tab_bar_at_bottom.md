---
tags:
  - tab_bar
---
# `tab_bar_at_bottom = false`

{{since('20210502-130208-bff6815d')}}

When `tab_bar_at_bottom = true`, the tab bar will be rendered at the bottom of
the window rather than the top of the window.

The default is `false`.

