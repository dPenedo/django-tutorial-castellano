---
tags:
  - multiplexing
---
# `tls_clients`

Configures TLS multiplexing domains.  [Read more about TLS Domains](
../../../multiplexing.md#tls-domains).

This option accepts a list of [TlsDomainClient](../TlsDomainClient.md) objects.

