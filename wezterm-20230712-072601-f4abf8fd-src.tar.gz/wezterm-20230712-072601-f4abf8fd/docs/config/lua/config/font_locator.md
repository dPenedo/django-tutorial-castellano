---
tags:
  - font
---
# `font_locator`

specifies the method by which system fonts are located and loaded.  You may
specify `ConfigDirsOnly` to disable loading system fonts and use only the fonts
found in the directories that you specify in your [font_dirs](font_dirs.md)
configuration option.

Otherwise, it is recommended to omit this setting.
