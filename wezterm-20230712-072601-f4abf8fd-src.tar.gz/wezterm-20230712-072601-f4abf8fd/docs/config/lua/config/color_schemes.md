---
tags:
  - color
---
# `color_schemes`

Specifies various named color schemes in your configuration file.

Described in more detail in [Colors & Appearance](../../appearance.md#defining-a-color-scheme-in-your-weztermlua)
