---
tags:
  - appearance
  - tab_bar
---
# `enable_tab_bar = true`

Controls whether the tab bar is enabled.
Set to `false` to disable it.

See also [hide_tab_bar_if_only_one_tab](hide_tab_bar_if_only_one_tab.md)


