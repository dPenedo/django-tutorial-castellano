---
tags:
  - font
---
# `font_hinting = "Full"`

*Deprecated starting in version 20210314-114017-04b7cedd; this option no longer does anything and will be removed in a future release. Use [freetype_load_target](freetype_load_target.md) instead*

Adjust the hinting portion of the font rasterizer.

Possible values are `None`, `Vertical`, `VerticalSubpixel`, `Full`.



