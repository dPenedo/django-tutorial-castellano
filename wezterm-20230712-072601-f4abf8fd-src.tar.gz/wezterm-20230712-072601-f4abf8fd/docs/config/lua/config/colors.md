---
tags:
  - color
---
# `colors`

Specifies the color palette.

Described in more detail in [Colors & Appearance](../../appearance.md#defining-your-own-colors)
