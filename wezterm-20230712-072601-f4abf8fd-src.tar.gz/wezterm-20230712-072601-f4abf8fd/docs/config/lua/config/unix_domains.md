---
tags:
  - multiplexing
---
# `unix_domains`

Defines a list of multiplexer domains for both the multiplexer
server and multiplexer client.

[Read more about multiplexing](../../../multiplexing.md#unix-domains)
