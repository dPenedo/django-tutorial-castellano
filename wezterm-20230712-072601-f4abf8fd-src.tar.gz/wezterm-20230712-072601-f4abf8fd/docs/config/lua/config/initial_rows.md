---
tags:
  - spawn
---
# `initial_rows = 24`

Together with [initial_cols](initial_cols.md), configures the window size
(window height) for newly created windows.

Specifies the height of a new window, expressed in character cells.
