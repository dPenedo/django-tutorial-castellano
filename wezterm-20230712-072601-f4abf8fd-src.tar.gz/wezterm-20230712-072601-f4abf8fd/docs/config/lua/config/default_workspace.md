---
tags:
  - multiplexing
  - workspace
---
# `default_workspace = "default"`

{{since('20220319-142410-0fcdea07')}}

Specifies the name of the default workspace.
The default is `"default"`.
