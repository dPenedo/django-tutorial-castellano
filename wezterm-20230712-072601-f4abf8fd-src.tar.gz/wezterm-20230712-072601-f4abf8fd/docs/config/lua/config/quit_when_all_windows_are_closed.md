# `quit_when_all_windows_are_closed = true`

{{since('20230320-124340-559cb7b0')}}

When set to `true`, wezterm will terminate when all windows are closed. This is
the default behavior.

When set to `false`, wezterm will continue running.

