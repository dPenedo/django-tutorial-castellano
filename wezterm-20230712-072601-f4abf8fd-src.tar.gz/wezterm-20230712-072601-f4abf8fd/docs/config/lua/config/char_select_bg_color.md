---
tags:
  - appearance
  - char_select
  - color
---
# `char_select_bg_color = "#333333"`

{{since('nightly')}}

Specifies the background color used by
[CharSelect](../keyassignment/CharSelect.md).
