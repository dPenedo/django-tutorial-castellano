---
tags:
  - tab_bar
---
# `tab_and_split_indices_are_zero_based = false`

If `true`, [show_tab_index_in_tab_bar](show_tab_index_in_tab_bar.md) uses a
zero-based index.  The default is `false` and the tab shows a one-based index.
