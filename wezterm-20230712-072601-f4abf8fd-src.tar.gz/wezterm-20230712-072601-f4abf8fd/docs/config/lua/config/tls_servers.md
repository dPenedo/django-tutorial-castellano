---
tags:
  - multiplexing
---
# `tls_servers`

Configures TLS multiplexing domains.  [Read more about TLS Domains](
../../../multiplexing.md#tls-domains).

This option accepts a list of [TlsDomainServer](../TlsDomainServer.md) objects.
