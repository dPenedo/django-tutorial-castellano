---
tags:
  - font
---
# `font_rasterizer`

Specifies the method by which fonts are rendered on screen.  The only available
implementation is `FreeType`.
