---
tags:
  - tab_bar
---
# `show_tab_index_in_tab_bar = true`

When set to `true` (the default), tab titles show their tab number (tab index) with a
prefix such as `1:`.  When false, no numeric prefix is shown.

The [tab_and_split_indices_are_zero_based](tab_and_split_indices_are_zero_based.md) setting controls whether numbering starts with `0` or `1`.
