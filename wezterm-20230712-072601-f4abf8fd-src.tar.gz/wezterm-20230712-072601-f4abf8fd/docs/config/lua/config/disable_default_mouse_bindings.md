---
tags:
  - mouse
---
# `disable_default_mouse_bindings = false`

If set to true, the default mouse assignments will not be used, allowing
you to tightly control those assignments.

