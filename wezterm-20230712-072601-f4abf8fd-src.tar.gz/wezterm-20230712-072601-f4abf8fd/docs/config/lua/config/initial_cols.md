---
tags:
  - spawn
---
# `initial_cols = 80`

Together with [initial_rows](initial_rows.md), configures the window size
(window width) for newly created windows.

Specifies the width of a new window, expressed in character cells.
