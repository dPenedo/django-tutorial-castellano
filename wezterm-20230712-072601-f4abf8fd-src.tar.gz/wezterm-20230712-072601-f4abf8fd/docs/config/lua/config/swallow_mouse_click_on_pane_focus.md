---
tags:
  - mouse
---
# `swallow_mouse_click_on_pane_focus = false`

{{since('20210502-130208-bff6815d')}}

When set to `true`, clicking on a pane will focus it.

When set to `false` (the default), clicking on a pane will focus it and then
pass the click through to the application in the terminal.


