---
tags:
  - appearance
  - char_select
  - color
---
# `char_select_fg_color = rgba(0.75, 0.75, 0.75, 1.0)`

{{since('nightly')}}

Specifies the text color used by
[CharSelect](../keyassignment/CharSelect.md).
