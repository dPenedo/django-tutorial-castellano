---
tags:
  - color
  - command_palette
---
# `command_palette_bg_color = "#333333"`

{{since('20230320-124340-559cb7b0')}}

Specifies the background color used by
[ActivateCommandPalette](../keyassignment/ActivateCommandPalette.md).

