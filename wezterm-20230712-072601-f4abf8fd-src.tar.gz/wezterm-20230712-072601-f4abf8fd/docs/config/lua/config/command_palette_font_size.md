---
tags:
  - font
  - command_palette
---
# `command_palette_font_size = 14.0`

{{since('20230320-124340-559cb7b0')}}

Specifies the size of the font used with
[ActivateCommandPalette](../keyassignment/ActivateCommandPalette.md).
