---
tags:
  - color
  - command_palette
---
# `command_palette_fg_color = rgba(0.75, 0.75, 0.75, 1.0)`

{{since('20230320-124340-559cb7b0')}}

Specifies the text color used by
[ActivateCommandPalette](../keyassignment/ActivateCommandPalette.md).
