---
tags:
  - scroll_bar
---
# `scrollback_lines = 3500`

How many lines of scrollback you want to retain.

[Learn more about scrollback](../../../scrollback.md)
