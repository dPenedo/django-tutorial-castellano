---
tags:
  - font
---
# `harfbuzz_features`

When `font_shaper = "Harfbuzz"`, this setting affects how font shaping
takes place.

See [Font Shaping](../../font-shaping.md) for more information
and examples.

