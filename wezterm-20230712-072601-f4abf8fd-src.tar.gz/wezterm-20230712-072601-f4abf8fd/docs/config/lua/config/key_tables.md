---
tags:
  - keys
---
# `key_tables = {}`

See the main [Key Tables](../../key-tables.md) docs!
