# `tab:activate()`

{{since('20230408-112425-69ae8472')}}

Activates (focuses) the tab.

