# `tab:get_title()`

{{since('20220807-113146-c2fee766')}}

Returns the tab title as set by `tab:set_title()`.


