# `tab:window()`

{{since('20220807-113146-c2fee766')}}

Returns the [MuxWindow](../mux-window/index.md) object that contains this tab.

