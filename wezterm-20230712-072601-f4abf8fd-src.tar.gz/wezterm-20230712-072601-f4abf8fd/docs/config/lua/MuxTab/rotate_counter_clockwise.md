# `tab:rotate_counter_clockwise()`

{{since('20230320-124340-559cb7b0')}}

Rotates the panes in the counter clockwise direction.

See also [tab:rotate_clockwise()](rotate_clockwise.md).

