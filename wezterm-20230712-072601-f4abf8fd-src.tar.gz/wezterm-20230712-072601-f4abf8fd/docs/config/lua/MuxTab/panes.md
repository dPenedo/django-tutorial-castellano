# `tab:panes()`

{{since('20220807-113146-c2fee766')}}

Returns an array table containing the set of [Pane](../pane/index.md) objects
contained by this tab.


