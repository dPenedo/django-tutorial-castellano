# `wezterm start`

```console
{% include "../examples/cmd-synopsis-wezterm-start--help.txt" %}
```
