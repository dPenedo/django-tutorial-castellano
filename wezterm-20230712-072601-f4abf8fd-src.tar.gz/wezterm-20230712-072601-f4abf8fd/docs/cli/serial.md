# `wezterm serial`

```console
{% include "../examples/cmd-synopsis-wezterm-serial--help.txt" %}
```



