# `wezterm replay`

```console
{% include "../examples/cmd-synopsis-wezterm-replay--help.txt" %}
```


