# `wezterm set-working-directory`

```console
{% include "../examples/cmd-synopsis-wezterm-set-working-directory--help.txt" %}
```

