# `wezterm cli set-tab-title TITLE`

{{since('20230408-112425-69ae8472')}}

*Run `wezterm cli set-tab-title --help` to see more help*

## Synopsis

```console
{% include "../../examples/cmd-synopsis-wezterm-cli-set-tab-title--help.txt" %}
```
