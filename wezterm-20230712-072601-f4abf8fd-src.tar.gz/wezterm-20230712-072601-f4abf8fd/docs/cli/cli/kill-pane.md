# `wezterm cli kill-pane`

{{since('20230326-111934-3666303c')}}

Immediately and without prompting, kills either the current pane, or the pane
specify via the `--pane-id` parameter.

## Synopsis

```console
{% include "../../examples/cmd-synopsis-wezterm-cli-kill-pane--help.txt" %}
```
