# `wezterm cli activate-pane`

{{since('20230326-111934-3666303c')}}

Activates the current pane, or the pane specified via the `--pane-id`
parameter.

## Synopsis

```console
{% include "../../examples/cmd-synopsis-wezterm-cli-activate-pane--help.txt" %}
```
