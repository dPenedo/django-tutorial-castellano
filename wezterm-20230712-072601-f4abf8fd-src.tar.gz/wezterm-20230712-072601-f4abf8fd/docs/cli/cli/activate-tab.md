# `wezterm cli activate-tab`

{{since('20230326-111934-3666303c')}}

## Synopsis

```console
{% include "../../examples/cmd-synopsis-wezterm-cli-activate-tab--help.txt" %}
```

