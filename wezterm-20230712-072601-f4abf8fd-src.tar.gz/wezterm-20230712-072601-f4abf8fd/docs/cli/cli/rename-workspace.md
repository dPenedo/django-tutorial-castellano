# `wezterm cli rename-workspace NEW-NAME`

{{since('20230408-112425-69ae8472')}}

*Run `wezterm cli rename-workspace --help` to see more help*

## Synopsis

```console
{% include "../../examples/cmd-synopsis-wezterm-cli-rename-workspace--help.txt" %}
```

