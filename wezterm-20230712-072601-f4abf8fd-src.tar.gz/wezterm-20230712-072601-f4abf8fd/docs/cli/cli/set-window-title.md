# `wezterm cli set-window-title TITLE`

{{since('20230408-112425-69ae8472')}}

*Run `wezterm cli set-window-title --help` to see more help*

## Synopsis

```console
{% include "../../examples/cmd-synopsis-wezterm-cli-set-window-title--help.txt" %}
```
