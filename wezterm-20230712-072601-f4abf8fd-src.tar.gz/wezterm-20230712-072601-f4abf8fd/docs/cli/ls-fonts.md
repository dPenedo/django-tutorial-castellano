# `wezterm ls-fonts`

```console
{% include "../examples/cmd-synopsis-wezterm-ls-fonts--help.txt" %}
```

