# `wezterm ssh`

```console
{% include "../examples/cmd-synopsis-wezterm-ssh--help.txt" %}
```

