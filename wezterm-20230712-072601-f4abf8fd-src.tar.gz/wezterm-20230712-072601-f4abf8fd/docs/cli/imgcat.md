# `wezterm imgcat`

```console
{% include "../examples/cmd-synopsis-wezterm-imgcat--help.txt" %}
```

