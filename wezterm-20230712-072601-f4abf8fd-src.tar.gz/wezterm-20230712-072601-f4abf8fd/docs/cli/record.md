# `wezterm record`

```console
{% include "../examples/cmd-synopsis-wezterm-record--help.txt" %}
```


