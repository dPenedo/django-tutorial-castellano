# `wezterm connect`

```console
{% include "../examples/cmd-synopsis-wezterm-connect--help.txt" %}
```

