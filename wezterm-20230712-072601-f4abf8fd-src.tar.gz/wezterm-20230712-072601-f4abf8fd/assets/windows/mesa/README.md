This is a pre-built opendl32.dll for 64-bit Windows systems.
It was obtained from <http://mesa.fdossena.com/>

Mesa's License text can be found here:
https://docs.mesa3d.org/license.html
(a mixture of largely MITish licenses)
